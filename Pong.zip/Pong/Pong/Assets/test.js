﻿#pragma strict

var Health : int = 100;

function Update () {
	
}